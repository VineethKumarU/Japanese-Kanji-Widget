package com.example.jlptkanjiwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val levelSpinner = findViewById<Spinner>(R.id.spinner_level)
        val intervalSpinner = findViewById<Spinner>(R.id.spinner_interval)
        val applyButton = findViewById<Button>(R.id.button_apply)

        val levels = listOf("ALL", "N5", "N4", "N3", "N2", "N1")
        levelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, levels)

        val intervals = listOf("15 min", "30 min", "60 min")
        intervalSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, intervals)

        val prefs = getSharedPreferences(KanjiWidgetProvider.PREFS, Context.MODE_PRIVATE)
        val savedLevel = prefs.getString(KanjiWidgetProvider.KEY_LEVEL, "ALL") ?: "ALL"
        levelSpinner.setSelection(levels.indexOf(savedLevel).coerceAtLeast(0))

        applyButton.setOnClickListener {
            val level = levels[levelSpinner.selectedItemPosition]
            val minutes = when (intervalSpinner.selectedItemPosition) {
                0 -> 15
                2 -> 60
                else -> 30
            }
            prefs.edit()
                .putString(KanjiWidgetProvider.KEY_LEVEL, level)
                .putInt(KanjiWidgetProvider.KEY_INTERVAL_MIN, minutes)
                .putInt(KanjiWidgetProvider.KEY_INDEX, 0)
                .apply()

            val appWidgetManager = AppWidgetManager.getInstance(this)
            val ids = appWidgetManager.getAppWidgetIds(ComponentName(this, KanjiWidgetProvider::class.java))
            for (id in ids) {
                KanjiWidgetProvider.updateAppWidget(this, appWidgetManager, id)
            }
            KanjiWidgetProvider.scheduleRotation(this)
        }
    }
}
