package com.example.jlptkanjiwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.RemoteViews

class KanjiWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_ROTATE = "com.example.jlptkanjiwidget.ACTION_ROTATE"
        const val PREFS = "jlpt_widget_prefs"
        const val KEY_INDEX = "kanji_index"
        const val KEY_LEVEL = "widget_level"
        const val KEY_INTERVAL_MIN = "widget_interval_min"

        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val level = prefs.getString(KEY_LEVEL, "ALL") ?: "ALL"
            val list = KanjiData.forLevel(context, level)
            if (list.isEmpty()) return
            val index = ((prefs.getInt(KEY_INDEX, 0) % list.size) + list.size) % list.size
            val entry = list[index]

            val views = RemoteViews(context.packageName, R.layout.widget_kanji)
            views.setTextViewText(R.id.widget_kanji, entry.kanji)
            views.setTextViewText(R.id.widget_reading, entry.reading + " — " + entry.meaning)
            views.setTextViewText(R.id.widget_phrase, entry.examplePhrase)
            views.setTextViewText(R.id.widget_romaji, entry.exampleRomaji + "  ·  " + entry.exampleMeaning)

            val rotateIntent = Intent(context, KanjiWidgetProvider::class.java).apply {
                action = ACTION_ROTATE
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context, appWidgetId, rotateIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }

        fun scheduleRotation(context: Context) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            // Android throttles background alarms for battery reasons, so a
            // few minutes is roughly the practical floor for a home-screen
            // widget on stock Android - true multi-second "frequent" rotation
            // isn't something the OS allows for battery reasons.
            val minutes = prefs.getInt(KEY_INTERVAL_MIN, 30).coerceAtLeast(15)
            val intervalMillis = minutes * 60_000L

            val intent = Intent(context, KanjiWidgetProvider::class.java).apply {
                action = ACTION_ROTATE
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.setInexactRepeating(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + intervalMillis,
                intervalMillis,
                pendingIntent
            )
        }

        fun cancelRotation(context: Context) {
            val intent = Intent(context, KanjiWidgetProvider::class.java).apply {
                action = ACTION_ROTATE
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(pendingIntent)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, id)
        }
        scheduleRotation(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_ROTATE) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val level = prefs.getString(KEY_LEVEL, "ALL") ?: "ALL"
            val size = KanjiData.forLevel(context, level).size.coerceAtLeast(1)
            val current = prefs.getInt(KEY_INDEX, 0)
            prefs.edit().putInt(KEY_INDEX, (current + 1) % size).apply()

            val appWidgetManager = AppWidgetManager.getInstance(context)
            val ids = appWidgetManager.getAppWidgetIds(
                ComponentName(context, KanjiWidgetProvider::class.java)
            )
            for (id in ids) {
                updateAppWidget(context, appWidgetManager, id)
            }
        }
    }

    override fun onDisabled(context: Context) {
        cancelRotation(context)
    }
}
