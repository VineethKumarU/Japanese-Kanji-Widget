package com.example.jlptkanjiwidget

import android.content.Context

data class KanjiEntry(
    val level: String,
    val kanji: String,
    val reading: String,
    val meaning: String,
    val examplePhrase: String,
    val exampleRomaji: String,
    val exampleMeaning: String
)

/**
 * The full kanji set (about 2,100 entries, N5-N1) lives in assets/kanji.tsv,
 * one tab-separated line per kanji:
 * level, kanji, reading, meaning, example phrase, example romaji, example meaning.
 *
 * To add or edit a kanji, just edit that file - no Kotlin changes needed.
 * (A giant listOf(...) in code would hit the JVM's method-size limit at this size.)
 */
object KanjiData {

    @Volatile
    private var cache: List<KanjiEntry>? = null

    fun all(context: Context): List<KanjiEntry> {
        cache?.let { return it }
        val loaded = context.applicationContext.assets.open("kanji.tsv")
            .bufferedReader(Charsets.UTF_8)
            .useLines { lines ->
                lines.filter { it.isNotBlank() }
                    .mapNotNull { line ->
                        val p = line.split('\t')
                        if (p.size < 7) null
                        else KanjiEntry(p[0], p[1], p[2], p[3], p[4], p[5], p[6])
                    }
                    .toList()
            }
        cache = loaded
        return loaded
    }

    fun forLevel(context: Context, level: String): List<KanjiEntry> {
        val all = all(context)
        return if (level == "ALL") all else all.filter { it.level == level }
    }
}
