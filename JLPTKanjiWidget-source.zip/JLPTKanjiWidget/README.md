# JLPT Kanji Widget (Android Studio project)

A home-screen widget that rotates through JLPT kanji — reading, meaning, an
example phrase in Japanese, and its romaji — plus a small settings screen to
pick a level (N5–N1 or All) and a rotation speed.

## Important, read first

- **This was written as source code, not compiled.** This environment has no
  Android SDK, emulator, or network access, so it could not be built, run, or
  tested here. Open it in Android Studio and do a clean build before relying
  on it — you may need to bump the Android Gradle Plugin / Kotlin versions in
  `build.gradle` to match whatever Android Studio installs for you.
- **There's no such thing as a real lock-screen widget on modern Android.**
  Google removed the keyguard-widget API in Android 5.0 (2014), so no
  third-party app can place a widget on the actual lock screen anymore.
  This project builds a **home-screen** widget instead, which is the closest
  supported equivalent.
- **"Frequent" rotation is limited by the OS.** Android throttles background
  alarms to save battery (Doze/App Standby), so home-screen widgets can't
  reliably refresh every few seconds. This project rotates via `AlarmManager`
  on a 15/30/60-minute cycle you choose in the app, and also advances one
  card whenever you tap the widget. Anything faster isn't practical on stock
  Android without draining the battery and getting throttled anyway.
- **The kanji set is large (about 2,100 kanji, N5-N1)** and lives in
  `app/src/main/assets/kanji.tsv`, one tab-separated line per kanji:
  `level, kanji, reading, meaning, example phrase, romaji, phrase meaning`.
  Edit or add lines there - no Kotlin changes needed. It is the same data as
  the web app. It follows community-compiled lists (JLPT publishes no official
  one), so counts per level differ slightly between sources.

## Requirements

- Android Studio (a recent version) with JDK 17
- An Android device or emulator running API 24+ (Android 7.0+)

## How to build and run

1. Open the `JLPTKanjiWidget` folder in Android Studio ("Open an existing project").
2. Let Gradle sync (it will download dependencies — needs internet).
3. Run the app on a device/emulator. This installs the app and its widget.
4. On the device: long-press the home screen → **Widgets** → find
   **JLPT Kanji Widget** → drag it onto the home screen.
5. Open the app itself to pick a JLPT level and rotation speed, then tap
   **Apply to widget**.
6. Tap the widget any time to manually advance to the next kanji.

## Project layout

```
app/src/main/java/com/example/jlptkanjiwidget/
  KanjiData.kt            – loads kanji.tsv from assets
  (assets/kanji.tsv)      – the kanji/phrase/romaji dataset
  KanjiWidgetProvider.kt  – the AppWidgetProvider (rendering + rotation logic)
  MainActivity.kt         – settings screen (level + speed)
app/src/main/res/layout/
  widget_kanji.xml        – widget's visual layout
  activity_main.xml       – settings screen layout
app/src/main/res/xml/kanji_widget_info.xml – widget size/update metadata
```

## Extending it

- Add more kanji: append lines to `assets/kanji.tsv`.
- Change widget looks: edit `res/layout/widget_kanji.xml` and
  `res/drawable/widget_background.xml`.
- Real launcher icon: replace `android:icon="@android:drawable/sym_def_app_icon"`
  in `AndroidManifest.xml` with your own mipmap icon set.
